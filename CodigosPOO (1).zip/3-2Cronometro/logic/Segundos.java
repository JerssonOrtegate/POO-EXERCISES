/*
 * Segundos.java
 * 
 * Created on 6/09/2007, 10:49:26 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author alejo
 */
class Segundos extends UnidadTiempo{

    public Segundos() {
        this.valor=0;
        this.tope=59;
    }

}
