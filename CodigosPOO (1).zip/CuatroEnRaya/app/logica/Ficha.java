package app.logica;

public class Ficha{
  private String forma;
  private String color;

  public String getForma (){
    return forma;
  }

  public String getColor (){
    return color;
  }

  public void setForma (String forma){
    this.forma = forma;
  }

  public void setColor (String color){
    this.color = color;
  }
}