public class HolaMundo{
  public static void main (String[] argsv){
    System.out.println ("Hola Mundo");
  }
}