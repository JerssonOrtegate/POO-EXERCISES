/*
 * Decimal.java
 *
 * Created on 29 de agosto de 2007, 09:40 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author alejo
 */
public class Decimal extends Sistema{
    
    /**
     * Creates a new instance of Decimal
     */
    public Decimal() {
        this.base=10;
    }
    
    

}
