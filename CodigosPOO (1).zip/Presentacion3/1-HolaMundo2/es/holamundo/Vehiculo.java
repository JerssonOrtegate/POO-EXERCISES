package es.holamundo;

public class Vehiculo {
    public String matricula;
}
