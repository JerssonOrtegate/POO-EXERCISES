public class AmbitoVariables {
 public static void main(String[] args) {
  int y;
  if (true) {
  y=5;
  }
  System.out.println(y);
 }
} 